package com.chargeready.app;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

// AdMob for the game page: the page calls window.ChargeReadyAds.show(id, kind) and hears back through window.__adDone(id, watched).
public class AdBridge {
    private final Activity activity;
    private final WebView web;
    private RewardedAd rewarded;
    private InterstitialAd interstitial;

    AdBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        MobileAds.initialize(activity, status -> { loadRewarded(); loadInterstitial(); });
    }

    // True when an ad of that kind is loaded and can show at once.
    @JavascriptInterface
    public boolean ready(String kind) {
        return "rewarded".equals(kind) ? rewarded != null : interstitial != null;
    }

    @JavascriptInterface
    public void show(final String id, final String kind) {
        activity.runOnUiThread(() -> {
            if ("rewarded".equals(kind)) showRewarded(id); else showInterstitial(id);
        });
    }

    private void showRewarded(String id) {
        if (rewarded == null) { done(id, false); loadRewarded(); return; }
        final boolean[] earned = { false };
        rewarded.setFullScreenContentCallback(closer(id, earned, true));
        rewarded.show(activity, reward -> earned[0] = true);
        rewarded = null;
    }

    private void showInterstitial(String id) {
        if (interstitial == null) { done(id, false); loadInterstitial(); return; }
        interstitial.setFullScreenContentCallback(closer(id, new boolean[] { true }, false));
        interstitial.show(activity);
        interstitial = null;
    }

    // Reports the result when the ad closes or fails, then loads the next one of that kind.
    private FullScreenContentCallback closer(final String id, final boolean[] ok, final boolean isRewarded) {
        return new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { finish(ok[0]); }
            @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { finish(false); }
            private void finish(boolean watched) {
                done(id, watched);
                if (isRewarded) loadRewarded(); else loadInterstitial();
            }
        };
    }

    private void loadRewarded() {
        RewardedAd.load(activity, activity.getString(R.string.admob_rewarded), new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull RewardedAd ad) { rewarded = ad; }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { rewarded = null; }
        });
    }

    private void loadInterstitial() {
        InterstitialAd.load(activity, activity.getString(R.string.admob_interstitial), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull InterstitialAd ad) { interstitial = ad; }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { interstitial = null; }
        });
    }

    private void done(String id, boolean watched) {
        final String js = "window.__adDone && window.__adDone(" + org.json.JSONObject.quote(id) + "," + watched + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }
}
