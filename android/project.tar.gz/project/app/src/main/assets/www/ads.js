// Ads and shop: rewarded videos, break ads and purchases share one card; the app build swaps the mock card for the ad SDK and store billing.
import { CONFIG } from './config.js';

const AD = CONFIG.ads, $ = (id) => document.getElementById(id);

// With skip (bots and tests) rewarded ads count as watched, break ads and offers never show, and buy() needs no confirm.
export function createAds(shop, { skip, track, onBuy }) {
  const card = $('adCard'), yes = $('adYes'), no = $('adNo');
  let lastAd = -Infinity;
  const now = () => performance.now() / 1000;

  // Shows the card and resolves with true for the main button, false for the other one.
  const ask = ({ title, body, note = '', ok, cancel, waitSec = 0 }) => new Promise((done) => {
    $('adTitle').textContent = title;
    $('adBody').textContent = body;
    $('adNote').textContent = note;
    no.textContent = cancel;
    card.hidden = false;
    let left = waitSec;
    const tick = () => { yes.disabled = left > 0; yes.textContent = left > 0 ? `${ok} ${left}` : ok; };
    tick();
    const timer = setInterval(() => { left--; tick(); if (left <= 0) clearInterval(timer); }, 1000);
    const end = (v) => { clearInterval(timer); card.hidden = true; yes.onclick = no.onclick = null; done(v); };
    yes.onclick = () => end(true);
    no.onclick = () => end(false);
  });

  const buy = async (key) => {
    const item = AD.shop[key];
    track(`shop_open_${key}`);
    if (!skip && !(await ask({ title: item.name, body: item.info, note: 'Test build: no real payment is taken', ok: item.price, cancel: 'Not now' }))) return false;
    shop[key] = true;
    if (key === 'starter') shop.noAds = true;
    track(`shop_buy_${key}`);
    onBuy(key);
    return true;
  };

  return {
    buy,
    // A rewarded video the player asked for; true when it was watched to the end.
    async rewarded(where) {
      track(`ad_offer_${where}`);
      const ok = skip || await ask({ title: '📺 Test ad', body: 'A short video ad plays here in the app.', ok: 'Collect', cancel: 'Skip', waitSec: AD.mockSec });
      lastAd = now();
      if (ok) track(`ad_done_${where}`);
      return ok;
    },
    // A break ad between stages, only when the player has no No Ads and the last ad is long enough ago.
    async breakAd() {
      if (skip || shop.noAds || now() - lastAd < AD.gapSec) return;
      lastAd = now();
      track('ad_break');
      if (!(await ask({ title: '📺 Test ad', body: 'A break ad plays here in the app.', ok: 'Close', cancel: `Remove ads ${AD.shop.noAds.price}`, waitSec: AD.mockSec }))) await buy('noAds');
    },
    // The starter pack is offered once, at the first stage card after starterAfterSec of play.
    async offerStarter() {
      if (skip || shop.offered || shop.starter) return false;
      shop.offered = true;
      await buy('starter');
      return true;
    },
  };
}
