// Fixed joystick at the bottom of the screen driven by a drag anywhere, plus WASD and arrow keys on desktop.
export function createInput(surface, radius) {
  const base = document.getElementById('joy'), knob = base.firstElementChild;
  const keys = new Set();
  let id = null, ox = 0, oy = 0, vec = { x: 0, y: 0 };
  base.style.width = base.style.height = `${radius * 2}px`;

  surface.addEventListener('pointerdown', (e) => {
    if (id !== null) return;
    id = e.pointerId; ox = e.clientX; oy = e.clientY;
    surface.setPointerCapture(id);
    base.classList.add('active');
  });
  surface.addEventListener('pointermove', (e) => {
    if (e.pointerId !== id) return;
    const dx = e.clientX - ox, dy = e.clientY - oy, k = Math.min(Math.hypot(dx, dy), radius) / (Math.hypot(dx, dy) || 1);
    vec = { x: dx * k / radius, y: dy * k / radius };
    knob.style.transform = `translate(${dx * k}px, ${dy * k}px)`;
  });
  const end = (e) => {
    if (e.pointerId !== id) return;
    id = null; vec = { x: 0, y: 0 };
    base.classList.remove('active'); knob.style.transform = '';
  };
  surface.addEventListener('pointerup', end);
  surface.addEventListener('pointercancel', end);
  addEventListener('keydown', (e) => keys.add(e.code));
  addEventListener('keyup', (e) => keys.delete(e.code));

  const key = (...codes) => codes.some((c) => keys.has(c));
  return () => {
    if (id !== null) return vec;
    const x = key('KeyD', 'ArrowRight') - key('KeyA', 'ArrowLeft'), y = key('KeyS', 'ArrowDown') - key('KeyW', 'ArrowUp');
    const len = Math.hypot(x, y) || 1;
    return { x: x / len, y: y / len };
  };
}
