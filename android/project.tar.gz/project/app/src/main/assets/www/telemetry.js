// Records each visit and each run milestone to the artifact db so playtests are timed without asking.
export function createTelemetry(state, fps) {
  let db = null, session = null;
  const pending = [], chains = {};
  const id = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

  // Writes to one document strictly one after another; queued until the db answers.
  const put = (path, data) => {
    const run = () => { chains[path] = (chains[path] ?? Promise.resolve()).then(() => db.doc(path).set(data)).catch(() => {}); };
    if (db) run(); else pending.push(run);
  };

  const begin = () => {
    session = { path: `sessions/${id()}`, data: { runId: state.runId, startedAt: new Date().toISOString(), playSecAtStart: Math.round(state.playSec) } };
    put(session.path, session.data);
  };
  const end = () => {
    if (!session) return;
    const { path, data } = session;
    put(path, { ...data, endedAt: new Date().toISOString(), activeSec: Math.round(state.playSec) - data.playSecAtStart, fps: fps() });
    session = null;
  };

  window.claude?.use('db').then((d) => {
    db = d;
    if (db) pending.splice(0).forEach((run) => run());
  });
  begin();
  document.addEventListener('visibilitychange', () => (document.hidden ? end() : begin()));
  addEventListener('pagehide', end);

  return {
    milestone(name) {
      put(`runs/${state.runId}/events/${name}`, { name, playSec: Math.round(state.playSec), fps: fps(), at: new Date().toISOString() });
    },
  };
}
